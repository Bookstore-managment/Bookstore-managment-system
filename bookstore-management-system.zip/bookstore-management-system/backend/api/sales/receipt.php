<?php
/**
 * Renders a printable receipt as a REAL page (not a JSON API response), so the
 * browser navigates to an actual URL - this avoids the "about:blank" address
 * bar issue that happens when a receipt is built client-side with document.write().
 */
require_once __DIR__ . '/../../includes/bootstrap.php';
requireLogin();

// bootstrap.php's sendSecurityHeaders() sets Content-Type: application/json and a
// strict CSP by default for API endpoints - override both here since this endpoint
// renders a real HTML page with its own inline <style> and the auto-print <script>.
header('Content-Type: text/html; charset=utf-8');
header("Content-Security-Policy: default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline';");

$pdo = getDBConnection();
$id = (int) ($_GET['id'] ?? 0);

if (!$id) {
    http_response_code(400);
    die('Missing sale id.');
}

$stmt = $pdo->prepare('SELECT * FROM sales WHERE sale_id = :id');
$stmt->execute(['id' => $id]);
$sale = $stmt->fetch();

if (!$sale) {
    http_response_code(404);
    die('Sale not found.');
}

$itemsStmt = $pdo->prepare(
    'SELECT si.quantity, si.unit_price, si.subtotal, b.title
     FROM sale_items si
     JOIN books b ON b.book_id = si.book_id
     WHERE si.sale_id = :id
     ORDER BY si.sale_item_id'
);
$itemsStmt->execute(['id' => $id]);
$items = $itemsStmt->fetchAll();

$dateStr = date('m/d/Y, H:i:s', strtotime($sale['created_at']));

// Store branding for the receipt header - pulled live from Settings so it stays
// in sync automatically whenever the store info or logo is updated.
$settingsRows = $pdo->query(
    "SELECT setting_key, setting_value FROM settings
     WHERE setting_key IN ('store_name','store_logo','store_phone','store_email','store_address','receipt_footer_message')"
)->fetchAll();
$settings = [];
foreach ($settingsRows as $row) {
    $settings[$row['setting_key']] = $row['setting_value'];
}
$storeName = $settings['store_name'] ?? 'Book Store';
$storeLogo = $settings['store_logo'] ?? '';
$storePhone = $settings['store_phone'] ?? '';
$storeEmail = $settings['store_email'] ?? '';
$storeAddress = $settings['store_address'] ?? '';
$footerMessage = $settings['receipt_footer_message'] ?? 'Thank you for your purchase!';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Receipt <?= escapeOutput($sale['invoice_number']) ?></title>
<style>
  body{font-family:monospace;background:#bfe0f7;margin:0;padding:32px 0;}
  .receipt{max-width:380px;margin:0 auto;background:#cfe8fb;padding:16px;border:1px solid #a9cfe8;}
  .line{border-top:1px dashed #5a90b8;margin:8px 0;}
  .right{text-align:right;}
  .store-header{display:flex;flex-direction:column;align-items:flex-start;text-align:left;gap:6px;margin-bottom:14px;}
  .store-header img{width:56px;height:56px;object-fit:contain;}
  .store-header .store-info{font-size:11px;line-height:1.5;}
  .store-header .store-name{font-size:14px;font-weight:bold;margin-bottom:2px;}
  .items-table{width:100%;border-collapse:collapse;font-size:12px;margin:6px 0;}
  .items-table th{text-align:left;padding:4px 0;border-bottom:1px solid #5a90b8;font-size:11px;}
  .items-table th.qty, .items-table td.qty{text-align:center;}
  .items-table th.amt, .items-table td.amt{text-align:right;}
  .items-table td{padding:4px 0;vertical-align:top;}
  @media print { body{background:#cfe8fb;padding:0;} .receipt{border:none;margin:0;max-width:none;} }
</style>
</head>
<body>
  <div class="receipt">
    <div class="store-header">
      <?php if ($storeLogo): ?>
        <img src="../../uploads/logo/<?= escapeOutput($storeLogo) ?>" alt="Logo">
      <?php endif; ?>
      <div class="store-info">
        <div class="store-name"><?= escapeOutput($storeName) ?></div>
        <?php if ($storePhone): ?><div><?= escapeOutput($storePhone) ?></div><?php endif; ?>
        <?php if ($storeEmail): ?><div><?= escapeOutput($storeEmail) ?></div><?php endif; ?>
        <?php if ($storeAddress): ?><div><?= escapeOutput($storeAddress) ?></div><?php endif; ?>
      </div>
    </div>
    <h3 style="text-align:center;">Book Store Receipt</h3>
    <p>Invoice: <?= escapeOutput($sale['invoice_number']) ?></p>
    <p>Date: <?= escapeOutput($dateStr) ?></p>
    <div class="line"></div>
    <table class="items-table">
      <thead>
        <tr><th>Item</th><th class="qty">Qty</th><th class="amt">Price</th><th class="amt">Amount</th></tr>
      </thead>
      <tbody>
        <?php foreach ($items as $item): ?>
        <tr>
          <td><?= escapeOutput($item['title']) ?></td>
          <td class="qty"><?= (int) $item['quantity'] ?></td>
          <td class="amt">$<?= number_format((float) $item['unit_price'], 2) ?></td>
          <td class="amt">$<?= number_format((float) $item['subtotal'], 2) ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <div class="line"></div>
    <p class="right">Subtotal: $<?= number_format((float) $sale['subtotal'], 2) ?></p>
    <p class="right">Discount: -$<?= number_format((float) $sale['discount_amount'], 2) ?></p>
    <p class="right">Tax: $<?= number_format((float) $sale['tax_amount'], 2) ?></p>
    <p class="right"><b>Total: $<?= number_format((float) $sale['total_amount'], 2) ?></b></p>
    <p class="right">Change: $<?= number_format((float) $sale['change_due'], 2) ?></p>
    <div class="line"></div>
    <p style="text-align:center;"><?= escapeOutput($footerMessage) ?></p>
  </div>
  <script>
    // Auto-close this tab once the print dialog is dismissed (printed OR cancelled),
    // so the person never has to look at the plain page underneath it.
    window.onafterprint = function () { window.close(); };
    window.print();
  </script>
</body>
</html>