-- Book Store Management System backup
-- Generated: 2026-07-13 08:05:59

SET FOREIGN_KEY_CHECKS=0;

DROP TABLE IF EXISTS `attendance`;
CREATE TABLE `attendance` (
  `attendance_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `work_date` date NOT NULL,
  `time_in` time DEFAULT NULL,
  `time_out` time DEFAULT NULL,
  `status` enum('Present','Absent','Leave') DEFAULT 'Present',
  PRIMARY KEY (`attendance_id`),
  KEY `employee_id` (`employee_id`),
  CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`employee_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `authors`;
CREATE TABLE `authors` (
  `author_id` int(11) NOT NULL AUTO_INCREMENT,
  `author_name` varchar(150) NOT NULL,
  `biography` text DEFAULT NULL,
  `nationality` varchar(80) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`author_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `books`;
CREATE TABLE `books` (
  `book_id` int(11) NOT NULL AUTO_INCREMENT,
  `isbn` varchar(30) NOT NULL,
  `title` varchar(255) NOT NULL,
  `author_id` int(11) DEFAULT NULL,
  `publisher_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `language` varchar(50) DEFAULT 'English',
  `edition` varchar(50) DEFAULT NULL,
  `publication_year` year(4) DEFAULT NULL,
  `purchase_price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `selling_price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `quantity` int(11) NOT NULL DEFAULT 0,
  `reorder_level` int(11) NOT NULL DEFAULT 5,
  `shelf_location` varchar(50) DEFAULT NULL,
  `cover_image` varchar(255) DEFAULT NULL,
  `status` enum('Available','Out of Stock','Discontinued') DEFAULT 'Available',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`book_id`),
  UNIQUE KEY `isbn` (`isbn`),
  KEY `author_id` (`author_id`),
  KEY `publisher_id` (`publisher_id`),
  KEY `category_id` (`category_id`),
  KEY `idx_title` (`title`),
  KEY `idx_isbn` (`isbn`),
  KEY `idx_status` (`status`),
  CONSTRAINT `books_ibfk_1` FOREIGN KEY (`author_id`) REFERENCES `authors` (`author_id`) ON DELETE SET NULL,
  CONSTRAINT `books_ibfk_2` FOREIGN KEY (`publisher_id`) REFERENCES `publishers` (`publisher_id`) ON DELETE SET NULL,
  CONSTRAINT `books_ibfk_3` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `books` (`book_id`,`isbn`,`title`,`author_id`,`publisher_id`,`category_id`,`language`,`edition`,`publication_year`,`purchase_price`,`selling_price`,`quantity`,`reorder_level`,`shelf_location`,`cover_image`,`status`,`created_at`,`updated_at`) VALUES ('1','00021','book',NULL,NULL,'3','English','Education','2001','45.00','55.00','6','5','Sr','4d33356aea508cf3b9a771dacd8fb70f.png','Available','2026-07-13 11:21:05','2026-07-13 15:03:00');

DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(100) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`category_id`),
  UNIQUE KEY `category_name` (`category_name`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `categories` (`category_id`,`category_name`,`description`,`created_at`) VALUES ('1','Fiction','Fictional literature','2026-07-13 11:02:55');
INSERT INTO `categories` (`category_id`,`category_name`,`description`,`created_at`) VALUES ('2','Non-Fiction','Non-fictional literature','2026-07-13 11:02:55');
INSERT INTO `categories` (`category_id`,`category_name`,`description`,`created_at`) VALUES ('3','Science','Science books','2026-07-13 11:02:55');
INSERT INTO `categories` (`category_id`,`category_name`,`description`,`created_at`) VALUES ('4','Technology','Technology and computing','2026-07-13 11:02:55');
INSERT INTO `categories` (`category_id`,`category_name`,`description`,`created_at`) VALUES ('5','Business','Business and finance','2026-07-13 11:02:55');
INSERT INTO `categories` (`category_id`,`category_name`,`description`,`created_at`) VALUES ('6','Education','Educational and academic','2026-07-13 11:02:55');
INSERT INTO `categories` (`category_id`,`category_name`,`description`,`created_at`) VALUES ('7','Children\'s Books','Books for children','2026-07-13 11:02:55');
INSERT INTO `categories` (`category_id`,`category_name`,`description`,`created_at`) VALUES ('8','Comics','Comics and graphic novels','2026-07-13 11:02:55');
INSERT INTO `categories` (`category_id`,`category_name`,`description`,`created_at`) VALUES ('9','Novels','Novels','2026-07-13 11:02:55');

DROP TABLE IF EXISTS `customers`;
CREATE TABLE `customers` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(150) NOT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `membership_id` int(11) DEFAULT 1,
  `membership_expiry` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`customer_id`),
  KEY `membership_id` (`membership_id`),
  CONSTRAINT `customers_ibfk_1` FOREIGN KEY (`membership_id`) REFERENCES `membership_levels` (`membership_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `discounts`;
CREATE TABLE `discounts` (
  `discount_id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(40) NOT NULL,
  `name` varchar(120) NOT NULL,
  `type` enum('percentage','fixed') NOT NULL,
  `value` decimal(10,2) NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `usage_limit` int(11) DEFAULT NULL,
  `used_count` int(11) DEFAULT 0,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`discount_id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `discounts` (`discount_id`,`code`,`name`,`type`,`value`,`start_date`,`end_date`,`usage_limit`,`used_count`,`status`,`created_at`) VALUES ('1','111','Mona','percentage','30.00','2026-07-14','2026-07-23','3','0','active','2026-07-13 11:48:42');

DROP TABLE IF EXISTS `employees`;
CREATE TABLE `employees` (
  `employee_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `full_name` varchar(150) NOT NULL,
  `position` varchar(100) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `hire_date` date DEFAULT NULL,
  `salary` decimal(10,2) DEFAULT 0.00,
  `status` enum('active','inactive') DEFAULT 'active',
  PRIMARY KEY (`employee_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `employees_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `inventory_transactions`;
CREATE TABLE `inventory_transactions` (
  `transaction_id` int(11) NOT NULL AUTO_INCREMENT,
  `book_id` int(11) NOT NULL,
  `type` enum('Stock In','Stock Out','Adjustment') NOT NULL,
  `quantity` int(11) NOT NULL,
  `reference` varchar(100) DEFAULT NULL,
  `notes` varchar(255) DEFAULT NULL,
  `performed_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`transaction_id`),
  KEY `book_id` (`book_id`),
  KEY `performed_by` (`performed_by`),
  CONSTRAINT `inventory_transactions_ibfk_1` FOREIGN KEY (`book_id`) REFERENCES `books` (`book_id`),
  CONSTRAINT `inventory_transactions_ibfk_2` FOREIGN KEY (`performed_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `inventory_transactions` (`transaction_id`,`book_id`,`type`,`quantity`,`reference`,`notes`,`performed_by`,`created_at`) VALUES ('1','1','Stock Out','4','INV-20260713-3C6D37',NULL,'3','2026-07-13 11:22:07');
INSERT INTO `inventory_transactions` (`transaction_id`,`book_id`,`type`,`quantity`,`reference`,`notes`,`performed_by`,`created_at`) VALUES ('2','1','Stock Out','2','INV-20260713-BDB262',NULL,'1','2026-07-13 11:41:00');
INSERT INTO `inventory_transactions` (`transaction_id`,`book_id`,`type`,`quantity`,`reference`,`notes`,`performed_by`,`created_at`) VALUES ('3','1','Stock Out','3','INV-20260713-75BF08',NULL,'1','2026-07-13 11:43:56');
INSERT INTO `inventory_transactions` (`transaction_id`,`book_id`,`type`,`quantity`,`reference`,`notes`,`performed_by`,`created_at`) VALUES ('4','1','Stock Out','1','INV-20260713-745188',NULL,'1','2026-07-13 11:49:11');
INSERT INTO `inventory_transactions` (`transaction_id`,`book_id`,`type`,`quantity`,`reference`,`notes`,`performed_by`,`created_at`) VALUES ('5','1','Stock Out','1','INV-20260713-F998BE',NULL,'1','2026-07-13 11:59:39');

DROP TABLE IF EXISTS `login_logs`;
CREATE TABLE `login_logs` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `username_attempt` varchar(50) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `status` enum('success','failed') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`log_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `login_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('1','2','kimly','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','success','2026-07-13 11:17:10');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('2','1','admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','success','2026-07-13 11:17:38');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('3','3','Manager','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','success','2026-07-13 11:18:53');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('4','1','admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','success','2026-07-13 11:24:37');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('5','2','kimly','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','success','2026-07-13 11:35:20');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('6','1','admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','success','2026-07-13 11:36:36');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('7','1','admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','success','2026-07-13 12:06:38');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('8','3','Manager','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','failed','2026-07-13 12:06:57');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('9','3','Manager','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','success','2026-07-13 12:07:05');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('10','1','admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','success','2026-07-13 14:40:39');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('11','1','admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','success','2026-07-13 14:51:11');

DROP TABLE IF EXISTS `membership_levels`;
CREATE TABLE `membership_levels` (
  `membership_id` int(11) NOT NULL AUTO_INCREMENT,
  `level_name` varchar(50) NOT NULL,
  `discount_percent` decimal(5,2) DEFAULT 0.00,
  `min_spend` decimal(10,2) DEFAULT 0.00,
  PRIMARY KEY (`membership_id`),
  UNIQUE KEY `level_name` (`level_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `membership_levels` (`membership_id`,`level_name`,`discount_percent`,`min_spend`) VALUES ('1','Bronze','0.00','0.00');
INSERT INTO `membership_levels` (`membership_id`,`level_name`,`discount_percent`,`min_spend`) VALUES ('2','Silver','5.00','100.00');
INSERT INTO `membership_levels` (`membership_id`,`level_name`,`discount_percent`,`min_spend`) VALUES ('3','Gold','10.00','300.00');

DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `notification_id` int(11) NOT NULL AUTO_INCREMENT,
  `type` enum('Low Stock','New Arrival','Purchase Reminder','Promotion','Membership Expiry') NOT NULL,
  `message` varchar(255) NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `user_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`notification_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `publishers`;
CREATE TABLE `publishers` (
  `publisher_id` int(11) NOT NULL AUTO_INCREMENT,
  `publisher_name` varchar(150) NOT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`publisher_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `publishers` (`publisher_id`,`publisher_name`,`phone`,`email`,`address`,`created_at`) VALUES ('1','Luna','032132654','luna@gmail.com','#06,Sr','2026-07-13 14:54:40');

DROP TABLE IF EXISTS `purchase_order_items`;
CREATE TABLE `purchase_order_items` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_cost` decimal(10,2) NOT NULL,
  `subtotal` decimal(12,2) NOT NULL,
  PRIMARY KEY (`item_id`),
  KEY `purchase_id` (`purchase_id`),
  KEY `book_id` (`book_id`),
  CONSTRAINT `purchase_order_items_ibfk_1` FOREIGN KEY (`purchase_id`) REFERENCES `purchase_orders` (`purchase_id`) ON DELETE CASCADE,
  CONSTRAINT `purchase_order_items_ibfk_2` FOREIGN KEY (`book_id`) REFERENCES `books` (`book_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `purchase_orders`;
CREATE TABLE `purchase_orders` (
  `purchase_id` int(11) NOT NULL AUTO_INCREMENT,
  `po_number` varchar(30) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `order_date` date NOT NULL,
  `expected_date` date DEFAULT NULL,
  `status` enum('Pending','Received','Cancelled') DEFAULT 'Pending',
  `total_amount` decimal(12,2) DEFAULT 0.00,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`purchase_id`),
  UNIQUE KEY `po_number` (`po_number`),
  KEY `supplier_id` (`supplier_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `purchase_orders_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`supplier_id`),
  CONSTRAINT `purchase_orders_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(50) NOT NULL,
  PRIMARY KEY (`role_id`),
  UNIQUE KEY `role_name` (`role_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `roles` (`role_id`,`role_name`) VALUES ('1','Admin');
INSERT INTO `roles` (`role_id`,`role_name`) VALUES ('3','Cashier');
INSERT INTO `roles` (`role_id`,`role_name`) VALUES ('2','Manager');

DROP TABLE IF EXISTS `sale_items`;
CREATE TABLE `sale_items` (
  `sale_item_id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `subtotal` decimal(12,2) NOT NULL,
  PRIMARY KEY (`sale_item_id`),
  KEY `sale_id` (`sale_id`),
  KEY `book_id` (`book_id`),
  CONSTRAINT `sale_items_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`sale_id`) ON DELETE CASCADE,
  CONSTRAINT `sale_items_ibfk_2` FOREIGN KEY (`book_id`) REFERENCES `books` (`book_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `sale_items` (`sale_item_id`,`sale_id`,`book_id`,`quantity`,`unit_price`,`subtotal`) VALUES ('1','1','1','4','55.00','220.00');
INSERT INTO `sale_items` (`sale_item_id`,`sale_id`,`book_id`,`quantity`,`unit_price`,`subtotal`) VALUES ('2','2','1','2','55.00','110.00');
INSERT INTO `sale_items` (`sale_item_id`,`sale_id`,`book_id`,`quantity`,`unit_price`,`subtotal`) VALUES ('3','3','1','3','55.00','165.00');
INSERT INTO `sale_items` (`sale_item_id`,`sale_id`,`book_id`,`quantity`,`unit_price`,`subtotal`) VALUES ('4','4','1','1','55.00','55.00');
INSERT INTO `sale_items` (`sale_item_id`,`sale_id`,`book_id`,`quantity`,`unit_price`,`subtotal`) VALUES ('5','5','1','1','55.00','55.00');

DROP TABLE IF EXISTS `sale_returns`;
CREATE TABLE `sale_returns` (
  `return_id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `refund_amount` decimal(10,2) NOT NULL,
  `processed_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`return_id`),
  KEY `sale_id` (`sale_id`),
  KEY `book_id` (`book_id`),
  KEY `processed_by` (`processed_by`),
  CONSTRAINT `sale_returns_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`sale_id`),
  CONSTRAINT `sale_returns_ibfk_2` FOREIGN KEY (`book_id`) REFERENCES `books` (`book_id`),
  CONSTRAINT `sale_returns_ibfk_3` FOREIGN KEY (`processed_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sales`;
CREATE TABLE `sales` (
  `sale_id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(30) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `cashier_id` int(11) NOT NULL,
  `discount_id` int(11) DEFAULT NULL,
  `subtotal` decimal(12,2) NOT NULL DEFAULT 0.00,
  `discount_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `tax_percent` decimal(5,2) NOT NULL DEFAULT 0.00,
  `tax_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `payment_method` enum('Cash','Card','Mobile') DEFAULT 'Cash',
  `amount_paid` decimal(12,2) DEFAULT 0.00,
  `change_due` decimal(12,2) DEFAULT 0.00,
  `status` enum('Completed','Cancelled','Refunded') DEFAULT 'Completed',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`sale_id`),
  UNIQUE KEY `invoice_number` (`invoice_number`),
  KEY `customer_id` (`customer_id`),
  KEY `cashier_id` (`cashier_id`),
  KEY `discount_id` (`discount_id`),
  KEY `idx_created` (`created_at`),
  CONSTRAINT `sales_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`) ON DELETE SET NULL,
  CONSTRAINT `sales_ibfk_2` FOREIGN KEY (`cashier_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `sales_ibfk_3` FOREIGN KEY (`discount_id`) REFERENCES `discounts` (`discount_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `sales` (`sale_id`,`invoice_number`,`customer_id`,`cashier_id`,`discount_id`,`subtotal`,`discount_amount`,`tax_percent`,`tax_amount`,`total_amount`,`payment_method`,`amount_paid`,`change_due`,`status`,`created_at`) VALUES ('1','INV-20260713-3C6D37',NULL,'3',NULL,'220.00','0.00','0.00','0.00','220.00','Cash','0.00','0.00','Cancelled','2026-07-13 11:22:07');
INSERT INTO `sales` (`sale_id`,`invoice_number`,`customer_id`,`cashier_id`,`discount_id`,`subtotal`,`discount_amount`,`tax_percent`,`tax_amount`,`total_amount`,`payment_method`,`amount_paid`,`change_due`,`status`,`created_at`) VALUES ('2','INV-20260713-BDB262',NULL,'1',NULL,'110.00','0.00','0.00','0.00','110.00','Card','100.00','0.00','Completed','2026-07-13 11:41:00');
INSERT INTO `sales` (`sale_id`,`invoice_number`,`customer_id`,`cashier_id`,`discount_id`,`subtotal`,`discount_amount`,`tax_percent`,`tax_amount`,`total_amount`,`payment_method`,`amount_paid`,`change_due`,`status`,`created_at`) VALUES ('3','INV-20260713-75BF08',NULL,'1',NULL,'165.00','0.00','0.00','0.00','165.00','Mobile','110.00','0.00','Completed','2026-07-13 11:43:56');
INSERT INTO `sales` (`sale_id`,`invoice_number`,`customer_id`,`cashier_id`,`discount_id`,`subtotal`,`discount_amount`,`tax_percent`,`tax_amount`,`total_amount`,`payment_method`,`amount_paid`,`change_due`,`status`,`created_at`) VALUES ('4','INV-20260713-745188',NULL,'1',NULL,'55.00','0.00','0.00','0.00','55.00','Cash','55.00','0.00','Completed','2026-07-13 11:49:11');
INSERT INTO `sales` (`sale_id`,`invoice_number`,`customer_id`,`cashier_id`,`discount_id`,`subtotal`,`discount_amount`,`tax_percent`,`tax_amount`,`total_amount`,`payment_method`,`amount_paid`,`change_due`,`status`,`created_at`) VALUES ('5','INV-20260713-F998BE',NULL,'1',NULL,'55.00','0.00','0.00','0.00','55.00','Cash','55.00','0.00','Completed','2026-07-13 11:59:39');

DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `setting_key` varchar(60) NOT NULL,
  `setting_value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES ('currency_code','USD');
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES ('currency_symbol','$');
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES ('low_stock_threshold','5');
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES ('store_address','');
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES ('store_email','');
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES ('store_logo','logo_d10baeb4980ce68f7d8c36e6.jpg');
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES ('store_name','THE BOOK STORE');
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES ('store_phone','');
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES ('tax_percent','0');

DROP TABLE IF EXISTS `suppliers`;
CREATE TABLE `suppliers` (
  `supplier_id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_name` varchar(150) NOT NULL,
  `contact_person` varchar(120) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`supplier_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `full_name` varchar(120) NOT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `role_id` int(11) NOT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `profile_image` varchar(255) DEFAULT NULL,
  `failed_login_attempts` int(11) DEFAULT 0,
  `locked_until` datetime DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `role_id` (`role_id`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` (`user_id`,`username`,`email`,`password_hash`,`full_name`,`phone`,`role_id`,`status`,`profile_image`,`failed_login_attempts`,`locked_until`,`last_login`,`created_at`,`updated_at`) VALUES ('1','admin','admin@bookstore.local','$2y$10$2bt3faqEQcF35WwQj.0ZvOyotGTEbfTJOXlFals2i3lz3P6LHUDFi','System Administrator',NULL,'1','active',NULL,'0',NULL,'2026-07-13 14:51:11','2026-07-13 11:02:55','2026-07-13 14:51:11');
INSERT INTO `users` (`user_id`,`username`,`email`,`password_hash`,`full_name`,`phone`,`role_id`,`status`,`profile_image`,`failed_login_attempts`,`locked_until`,`last_login`,`created_at`,`updated_at`) VALUES ('2','kimly','kimly@gmail.com','$2y$10$Bo08B8Aj1D49Jt1/HXefrO.Pjc5M5czziBcbFpYfZjmopIi9xJv6i','mutha kimly','032652326','3','active',NULL,'0',NULL,'2026-07-13 11:35:20','2026-07-13 11:15:28','2026-07-13 11:35:20');
INSERT INTO `users` (`user_id`,`username`,`email`,`password_hash`,`full_name`,`phone`,`role_id`,`status`,`profile_image`,`failed_login_attempts`,`locked_until`,`last_login`,`created_at`,`updated_at`) VALUES ('3','Manager','Ma@gmail.com','$2y$10$nVadE53yt9O4lFOMmKZt4OdqjhFedwfcilEUHLH6fRJBz.O3vX1hm','manager','06566566','2','active',NULL,'0',NULL,'2026-07-13 12:07:05','2026-07-13 11:18:34','2026-07-13 12:07:05');

DROP TABLE IF EXISTS `view_best_sellers`;
;

INSERT INTO `view_best_sellers` (`book_id`,`title`,`total_sold`) VALUES ('1','book','7');

DROP TABLE IF EXISTS `view_low_stock`;
;


DROP TABLE IF EXISTS `work_schedule`;
CREATE TABLE `work_schedule` (
  `schedule_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `shift_day` varchar(20) NOT NULL,
  `shift_start` time NOT NULL,
  `shift_end` time NOT NULL,
  PRIMARY KEY (`schedule_id`),
  KEY `employee_id` (`employee_id`),
  CONSTRAINT `work_schedule_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`employee_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


SET FOREIGN_KEY_CHECKS=1;
