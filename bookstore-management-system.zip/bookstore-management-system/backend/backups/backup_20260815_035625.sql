-- Book Store Management System backup
-- Generated: 2026-08-15 03:56:25

SET FOREIGN_KEY_CHECKS=0;

DROP TABLE IF EXISTS `attendance`;
CREATE TABLE `attendance` (
  `attendance_id` int NOT NULL AUTO_INCREMENT,
  `employee_id` int NOT NULL,
  `work_date` date NOT NULL,
  `time_in` time DEFAULT NULL,
  `time_out` time DEFAULT NULL,
  `status` enum('Present','Absent','Leave') COLLATE utf8mb4_unicode_ci DEFAULT 'Present',
  PRIMARY KEY (`attendance_id`),
  KEY `employee_id` (`employee_id`),
  CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`employee_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `authors`;
CREATE TABLE `authors` (
  `author_id` int NOT NULL AUTO_INCREMENT,
  `author_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `biography` text COLLATE utf8mb4_unicode_ci,
  `nationality` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`author_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `authors` (`author_id`,`author_name`,`biography`,`nationality`,`created_at`) VALUES ('1','Michael Workman','Famous man','France','2026-07-28 20:21:21');
INSERT INTO `authors` (`author_id`,`author_name`,`biography`,`nationality`,`created_at`) VALUES ('2','Marshall B','blahh blahhh','English','2026-07-28 20:21:50');
INSERT INTO `authors` (`author_id`,`author_name`,`biography`,`nationality`,`created_at`) VALUES ('3','Mao somnang','','Cambodia','2026-07-28 20:22:04');
INSERT INTO `authors` (`author_id`,`author_name`,`biography`,`nationality`,`created_at`) VALUES ('4','Mao Reaksmey','','Cambodia','2026-07-28 20:22:15');
INSERT INTO `authors` (`author_id`,`author_name`,`biography`,`nationality`,`created_at`) VALUES ('5','Andrew Stellman','','Spain','2026-07-28 20:22:27');
INSERT INTO `authors` (`author_id`,`author_name`,`biography`,`nationality`,`created_at`) VALUES ('6','Arye L. Hillman','','English','2026-07-28 20:22:48');
INSERT INTO `authors` (`author_id`,`author_name`,`biography`,`nationality`,`created_at`) VALUES ('7','David N. Hyman','','France','2026-07-28 20:22:59');
INSERT INTO `authors` (`author_id`,`author_name`,`biography`,`nationality`,`created_at`) VALUES ('8','Shadab Saifi','','France','2026-07-28 20:23:21');
INSERT INTO `authors` (`author_id`,`author_name`,`biography`,`nationality`,`created_at`) VALUES ('9','Robert N','','Italy','2026-07-28 20:23:49');
INSERT INTO `authors` (`author_id`,`author_name`,`biography`,`nationality`,`created_at`) VALUES ('10','Laurence S','','Northway','2026-07-28 20:24:34');
INSERT INTO `authors` (`author_id`,`author_name`,`biography`,`nationality`,`created_at`) VALUES ('11','Lee Rotanakvimean','scam, tricks,','Indian','2026-07-30 11:15:11');

DROP TABLE IF EXISTS `books`;
CREATE TABLE `books` (
  `book_id` int NOT NULL AUTO_INCREMENT,
  `isbn` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `author_id` int DEFAULT NULL,
  `publisher_id` int DEFAULT NULL,
  `category_id` int DEFAULT NULL,
  `language` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'English',
  `edition` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `publication_year` year DEFAULT NULL,
  `purchase_price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `selling_price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `quantity` int NOT NULL DEFAULT '0',
  `reorder_level` int NOT NULL DEFAULT '5',
  `shelf_location` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cover_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('Available','Out of Stock','Discontinued') COLLATE utf8mb4_unicode_ci DEFAULT 'Available',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`book_id`),
  UNIQUE KEY `isbn` (`isbn`),
  KEY `author_id` (`author_id`),
  KEY `publisher_id` (`publisher_id`),
  KEY `category_id` (`category_id`),
  KEY `idx_title` (`title`),
  KEY `idx_isbn` (`isbn`),
  KEY `idx_status` (`status`),
  CONSTRAINT `books_ibfk_1` FOREIGN KEY (`author_id`) REFERENCES `authors` (`author_id`) ON DELETE SET NULL,
  CONSTRAINT `books_ibfk_2` FOREIGN KEY (`publisher_id`) REFERENCES `publishers` (`publisher_id`) ON DELETE SET NULL,
  CONSTRAINT `books_ibfk_3` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `books` (`book_id`,`isbn`,`title`,`author_id`,`publisher_id`,`category_id`,`language`,`edition`,`publication_year`,`purchase_price`,`selling_price`,`quantity`,`reorder_level`,`shelf_location`,`cover_image`,`status`,`created_at`,`updated_at`) VALUES ('1','01','Information Security managment','6','3','6','English','1st Edition','2000','8.00','13.00','5','2','#30st,SR','d445912188d7b02a68e7f3c5670c9b28.jpg','Available','2026-07-28 20:56:48','2026-07-30 20:49:23');
INSERT INTO `books` (`book_id`,`isbn`,`title`,`author_id`,`publisher_id`,`category_id`,`language`,`edition`,`publication_year`,`purchase_price`,`selling_price`,`quantity`,`reorder_level`,`shelf_location`,`cover_image`,`status`,`created_at`,`updated_at`) VALUES ('2','02','Accounting information system','4','1','6','English','1st Edition','2005','7.00','10.00','1','2','#32st,sr','b60b483ad65c10dcedf9599867667f7a.jpg','Available','2026-07-28 20:58:20','2026-07-30 20:49:11');
INSERT INTO `books` (`book_id`,`isbn`,`title`,`author_id`,`publisher_id`,`category_id`,`language`,`edition`,`publication_year`,`purchase_price`,`selling_price`,`quantity`,`reorder_level`,`shelf_location`,`cover_image`,`status`,`created_at`,`updated_at`) VALUES ('3','03','Information Security and Cyber Laws','2','5','6','English','1st Edition','2006','8.00','13.00','4','2','','8973ffb1d133a6029cf5384779ba3f7c.jpg','Available','2026-07-28 20:59:31','2026-07-30 20:48:52');
INSERT INTO `books` (`book_id`,`isbn`,`title`,`author_id`,`publisher_id`,`category_id`,`language`,`edition`,`publication_year`,`purchase_price`,`selling_price`,`quantity`,`reorder_level`,`shelf_location`,`cover_image`,`status`,`created_at`,`updated_at`) VALUES ('4','04','Leadership','10','4','6','English','2nd edition','2004','10.00','14.00','0','2','','ce4dc578dce3acea39ea1ee787d76803.jpg','Out of Stock','2026-07-28 21:00:29','2026-07-30 20:49:03');
INSERT INTO `books` (`book_id`,`isbn`,`title`,`author_id`,`publisher_id`,`category_id`,`language`,`edition`,`publication_year`,`purchase_price`,`selling_price`,`quantity`,`reorder_level`,`shelf_location`,`cover_image`,`status`,`created_at`,`updated_at`) VALUES ('5','05','Public Finace','1','4','6','English','2nd edition','2005','8.00','13.00','1','3','','a74ad4de23b3cdde0ce3faa08d055e4f.png','Available','2026-07-28 21:02:44','2026-07-30 20:48:19');
INSERT INTO `books` (`book_id`,`isbn`,`title`,`author_id`,`publisher_id`,`category_id`,`language`,`edition`,`publication_year`,`purchase_price`,`selling_price`,`quantity`,`reorder_level`,`shelf_location`,`cover_image`,`status`,`created_at`,`updated_at`) VALUES ('6','06','Critical Thinking','2','6','6','English','2nd edition','2005','7.00','10.00','6','5','','b4842a4286eb901d8f240f2516868ddd.png','Available','2026-07-28 21:04:06','2026-07-30 20:48:04');
INSERT INTO `books` (`book_id`,`isbn`,`title`,`author_id`,`publisher_id`,`category_id`,`language`,`edition`,`publication_year`,`purchase_price`,`selling_price`,`quantity`,`reorder_level`,`shelf_location`,`cover_image`,`status`,`created_at`,`updated_at`) VALUES ('7','07','public policy','1','4','5','English','2nd edition','2004','6.00','10.00','6','5','','3641fc95429ec664e978732c5ffebf25.jpg','Available','2026-07-28 21:05:23','2026-07-30 20:47:56');
INSERT INTO `books` (`book_id`,`isbn`,`title`,`author_id`,`publisher_id`,`category_id`,`language`,`edition`,`publication_year`,`purchase_price`,`selling_price`,`quantity`,`reorder_level`,`shelf_location`,`cover_image`,`status`,`created_at`,`updated_at`) VALUES ('8','08','Cybersecurity','8','3','8','English','2nd edition','2016','10.00','16.00','5','5','','d49befb4177035ec747ceeb4c7993540.jpg','Available','2026-07-28 21:06:37','2026-07-30 20:47:49');
INSERT INTO `books` (`book_id`,`isbn`,`title`,`author_id`,`publisher_id`,`category_id`,`language`,`edition`,`publication_year`,`purchase_price`,`selling_price`,`quantity`,`reorder_level`,`shelf_location`,`cover_image`,`status`,`created_at`,`updated_at`) VALUES ('9','09','Javascript','7','2','2','English','1st Edition','2015','10.00','15.00','2','5','','54eb1ef2c3b2472835198f29ed1f2e14.jpg','Available','2026-07-28 21:07:40','2026-07-30 20:47:39');
INSERT INTO `books` (`book_id`,`isbn`,`title`,`author_id`,`publisher_id`,`category_id`,`language`,`edition`,`publication_year`,`purchase_price`,`selling_price`,`quantity`,`reorder_level`,`shelf_location`,`cover_image`,`status`,`created_at`,`updated_at`) VALUES ('15','010','chemistry','2','1','6','English','1st Edition','2015','5.00','8.00','9','5','','4d0822477b1d1baeea6d2de928097f1e.jpg','Available','2026-07-29 18:54:50','2026-07-30 20:47:30');
INSERT INTO `books` (`book_id`,`isbn`,`title`,`author_id`,`publisher_id`,`category_id`,`language`,`edition`,`publication_year`,`purchase_price`,`selling_price`,`quantity`,`reorder_level`,`shelf_location`,`cover_image`,`status`,`created_at`,`updated_at`) VALUES ('16','007','The Art of Scamming','11','7','10','English','1st Edition','2026','9.99','99.99','29','5','Sr','2005f7fec187c8ddd2db46ad830a52c7.jpg','Out of Stock','2026-07-30 11:20:46','2026-08-03 20:25:00');
INSERT INTO `books` (`book_id`,`isbn`,`title`,`author_id`,`publisher_id`,`category_id`,`language`,`edition`,`publication_year`,`purchase_price`,`selling_price`,`quantity`,`reorder_level`,`shelf_location`,`cover_image`,`status`,`created_at`,`updated_at`) VALUES ('17','0012','HTML&Javascript','5','2','6','English','1st Edition','2015','8.00','10.00','10','2','#30st,SR','7b2d2e0bff91075c645815d45de8a292.jpg','Available','2026-07-31 18:40:31','2026-07-31 18:40:31');
INSERT INTO `books` (`book_id`,`isbn`,`title`,`author_id`,`publisher_id`,`category_id`,`language`,`edition`,`publication_year`,`purchase_price`,`selling_price`,`quantity`,`reorder_level`,`shelf_location`,`cover_image`,`status`,`created_at`,`updated_at`) VALUES ('18','0016','World Book','3','1','6','English','1st Edition','2016','7.00','9.00','5','2','','355cee1ccbd27c5ea681e373de99ea5e.jpg','Available','2026-07-31 18:41:16','2026-07-31 18:41:16');
INSERT INTO `books` (`book_id`,`isbn`,`title`,`author_id`,`publisher_id`,`category_id`,`language`,`edition`,`publication_year`,`purchase_price`,`selling_price`,`quantity`,`reorder_level`,`shelf_location`,`cover_image`,`status`,`created_at`,`updated_at`) VALUES ('19','0015','Cyber hacking','2','5','10','English','5th edition','2014','6.00','8.00','6','2','#30st,SR','cafdd584f826d17f901a58990cc5a59b.png','Available','2026-07-31 18:42:28','2026-07-31 18:42:28');
INSERT INTO `books` (`book_id`,`isbn`,`title`,`author_id`,`publisher_id`,`category_id`,`language`,`edition`,`publication_year`,`purchase_price`,`selling_price`,`quantity`,`reorder_level`,`shelf_location`,`cover_image`,`status`,`created_at`,`updated_at`) VALUES ('20','045','Java','7','6','6','English','1st Edition',NULL,'5.00','7.00','31','2','#30st,SR','84b56de31697c1711eaac5aace0e9f49.jpg','Available','2026-07-31 19:08:26','2026-08-03 18:42:08');

DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `category_id` int NOT NULL AUTO_INCREMENT,
  `category_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`category_id`),
  UNIQUE KEY `category_name` (`category_name`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `categories` (`category_id`,`category_name`,`description`,`created_at`) VALUES ('1','Fiction','Fictional literature','2026-07-28 20:13:40');
INSERT INTO `categories` (`category_id`,`category_name`,`description`,`created_at`) VALUES ('2','Non-Fiction','Non-fictional literature','2026-07-28 20:13:40');
INSERT INTO `categories` (`category_id`,`category_name`,`description`,`created_at`) VALUES ('3','Science','Science books','2026-07-28 20:13:40');
INSERT INTO `categories` (`category_id`,`category_name`,`description`,`created_at`) VALUES ('4','Technology','Technology and computing','2026-07-28 20:13:40');
INSERT INTO `categories` (`category_id`,`category_name`,`description`,`created_at`) VALUES ('5','Business','Business and finance','2026-07-28 20:13:40');
INSERT INTO `categories` (`category_id`,`category_name`,`description`,`created_at`) VALUES ('6','Education','Educational and academic','2026-07-28 20:13:40');
INSERT INTO `categories` (`category_id`,`category_name`,`description`,`created_at`) VALUES ('7','Children\'s Books','Books for children','2026-07-28 20:13:40');
INSERT INTO `categories` (`category_id`,`category_name`,`description`,`created_at`) VALUES ('8','Comics','Comics and graphic novels','2026-07-28 20:13:40');
INSERT INTO `categories` (`category_id`,`category_name`,`description`,`created_at`) VALUES ('9','Novels','Novels','2026-07-28 20:13:40');
INSERT INTO `categories` (`category_id`,`category_name`,`description`,`created_at`) VALUES ('10','Scam','Scamming people','2026-07-30 11:18:29');

DROP TABLE IF EXISTS `customers`;
CREATE TABLE `customers` (
  `customer_id` int NOT NULL AUTO_INCREMENT,
  `full_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `membership_id` int DEFAULT '1',
  `membership_expiry` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`customer_id`),
  KEY `membership_id` (`membership_id`),
  CONSTRAINT `customers_ibfk_1` FOREIGN KEY (`membership_id`) REFERENCES `membership_levels` (`membership_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `customers` (`customer_id`,`full_name`,`phone`,`email`,`address`,`membership_id`,`membership_expiry`,`created_at`) VALUES ('1','Tola','0987654324','Tolasava@gmail.com','','1',NULL,'2026-07-28 20:44:29');
INSERT INTO `customers` (`customer_id`,`full_name`,`phone`,`email`,`address`,`membership_id`,`membership_expiry`,`created_at`) VALUES ('2','Kimchea','098765432','Kimcheaborkke@gmail.com','','1',NULL,'2026-07-28 20:45:01');
INSERT INTO `customers` (`customer_id`,`full_name`,`phone`,`email`,`address`,`membership_id`,`membership_expiry`,`created_at`) VALUES ('3','Panha','098765456','Panha150@gmail.com','','1',NULL,'2026-07-28 20:45:41');
INSERT INTO `customers` (`customer_id`,`full_name`,`phone`,`email`,`address`,`membership_id`,`membership_expiry`,`created_at`) VALUES ('4','Seyha','09876545','Seyhamuksmer@gmail.com','','1',NULL,'2026-07-28 20:46:15');
INSERT INTO `customers` (`customer_id`,`full_name`,`phone`,`email`,`address`,`membership_id`,`membership_expiry`,`created_at`) VALUES ('5','B vid','0987654334','bvid@gmail.com','','1',NULL,'2026-07-28 20:46:37');
INSERT INTO `customers` (`customer_id`,`full_name`,`phone`,`email`,`address`,`membership_id`,`membership_expiry`,`created_at`) VALUES ('6','Sophal','098765432','sophal@gmail.com','','1',NULL,'2026-07-28 20:47:00');

DROP TABLE IF EXISTS `discounts`;
CREATE TABLE `discounts` (
  `discount_id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('percentage','fixed') COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` decimal(10,2) NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `usage_limit` int DEFAULT NULL,
  `used_count` int DEFAULT '0',
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`discount_id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `discounts` (`discount_id`,`code`,`name`,`type`,`value`,`start_date`,`end_date`,`usage_limit`,`used_count`,`status`,`created_at`) VALUES ('1','001','Mother\'s day','percentage','2.50','2026-07-28','2026-07-30','2','0','active','2026-07-28 20:52:58');
INSERT INTO `discounts` (`discount_id`,`code`,`name`,`type`,`value`,`start_date`,`end_date`,`usage_limit`,`used_count`,`status`,`created_at`) VALUES ('2','002','ទិវាអំណានជាតិ','percentage','2.00','2026-07-28','2026-07-29','1','0','active','2026-07-28 20:54:15');
INSERT INTO `discounts` (`discount_id`,`code`,`name`,`type`,`value`,`start_date`,`end_date`,`usage_limit`,`used_count`,`status`,`created_at`) VALUES ('3','003','father\'s day','percentage','2.00','2026-07-30','2026-07-31','1','0','active','2026-07-28 20:54:51');

DROP TABLE IF EXISTS `employees`;
CREATE TABLE `employees` (
  `employee_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `full_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `position` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hire_date` date DEFAULT NULL,
  `salary` decimal(10,2) DEFAULT '0.00',
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  PRIMARY KEY (`employee_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `employees_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `employees` (`employee_id`,`user_id`,`full_name`,`position`,`phone`,`email`,`hire_date`,`salary`,`status`) VALUES ('1',NULL,'Vatey','Sale','09876543234','VAtey@gmail.com','2026-07-01','1000.00','active');
INSERT INTO `employees` (`employee_id`,`user_id`,`full_name`,`position`,`phone`,`email`,`hire_date`,`salary`,`status`) VALUES ('2',NULL,'Ratanak','Manager','0978886197','ratanaknaokhorn@gmail.com','2026-07-09','2000.00','active');
INSERT INTO `employees` (`employee_id`,`user_id`,`full_name`,`position`,`phone`,`email`,`hire_date`,`salary`,`status`) VALUES ('3',NULL,'Vimean','Service','0876543456','Vimean@gmail.com','2026-07-11','500.00','active');
INSERT INTO `employees` (`employee_id`,`user_id`,`full_name`,`position`,`phone`,`email`,`hire_date`,`salary`,`status`) VALUES ('4',NULL,'Linda','Account','0987654345','Linda@gmail.com','2026-07-18','800.00','active');

DROP TABLE IF EXISTS `inventory_transactions`;
CREATE TABLE `inventory_transactions` (
  `transaction_id` int NOT NULL AUTO_INCREMENT,
  `book_id` int NOT NULL,
  `type` enum('Stock In','Stock Out','Adjustment') COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int NOT NULL,
  `reference` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `performed_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`transaction_id`),
  KEY `book_id` (`book_id`),
  KEY `performed_by` (`performed_by`),
  CONSTRAINT `inventory_transactions_ibfk_1` FOREIGN KEY (`book_id`) REFERENCES `books` (`book_id`),
  CONSTRAINT `inventory_transactions_ibfk_2` FOREIGN KEY (`performed_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `inventory_transactions` (`transaction_id`,`book_id`,`type`,`quantity`,`reference`,`notes`,`performed_by`,`created_at`) VALUES ('1','6','Stock In','5','Manual','','1','2026-07-28 21:10:08');
INSERT INTO `inventory_transactions` (`transaction_id`,`book_id`,`type`,`quantity`,`reference`,`notes`,`performed_by`,`created_at`) VALUES ('2','4','Stock In','8','Manual','','1','2026-07-28 21:10:21');
INSERT INTO `inventory_transactions` (`transaction_id`,`book_id`,`type`,`quantity`,`reference`,`notes`,`performed_by`,`created_at`) VALUES ('3','3','Stock In','8','Manual','','1','2026-07-28 21:10:33');
INSERT INTO `inventory_transactions` (`transaction_id`,`book_id`,`type`,`quantity`,`reference`,`notes`,`performed_by`,`created_at`) VALUES ('4','2','Stock Out','3','INV-20260728-36D1EB',NULL,'1','2026-07-28 21:12:32');
INSERT INTO `inventory_transactions` (`transaction_id`,`book_id`,`type`,`quantity`,`reference`,`notes`,`performed_by`,`created_at`) VALUES ('5','9','Stock In','1','PO#2',NULL,'1','2026-07-28 21:13:24');
INSERT INTO `inventory_transactions` (`transaction_id`,`book_id`,`type`,`quantity`,`reference`,`notes`,`performed_by`,`created_at`) VALUES ('6','6','Stock In','10','PO#2',NULL,'1','2026-07-28 21:13:24');
INSERT INTO `inventory_transactions` (`transaction_id`,`book_id`,`type`,`quantity`,`reference`,`notes`,`performed_by`,`created_at`) VALUES ('7','3','Stock In','10','PO#2',NULL,'1','2026-07-28 21:13:24');
INSERT INTO `inventory_transactions` (`transaction_id`,`book_id`,`type`,`quantity`,`reference`,`notes`,`performed_by`,`created_at`) VALUES ('8','9','Stock Out','9','INV-20260729-F51C64',NULL,'1','2026-07-29 20:50:12');
INSERT INTO `inventory_transactions` (`transaction_id`,`book_id`,`type`,`quantity`,`reference`,`notes`,`performed_by`,`created_at`) VALUES ('9','8','Stock Out','7','INV-20260729-F51C64',NULL,'1','2026-07-29 20:50:12');
INSERT INTO `inventory_transactions` (`transaction_id`,`book_id`,`type`,`quantity`,`reference`,`notes`,`performed_by`,`created_at`) VALUES ('10','15','Stock Out','8','INV-20260729-F51C64',NULL,'1','2026-07-29 20:50:12');
INSERT INTO `inventory_transactions` (`transaction_id`,`book_id`,`type`,`quantity`,`reference`,`notes`,`performed_by`,`created_at`) VALUES ('11','6','Stock Out','24','INV-20260729-F51C64',NULL,'1','2026-07-29 20:50:12');
INSERT INTO `inventory_transactions` (`transaction_id`,`book_id`,`type`,`quantity`,`reference`,`notes`,`performed_by`,`created_at`) VALUES ('12','5','Stock Out','4','INV-20260729-F51C64',NULL,'1','2026-07-29 20:50:12');
INSERT INTO `inventory_transactions` (`transaction_id`,`book_id`,`type`,`quantity`,`reference`,`notes`,`performed_by`,`created_at`) VALUES ('13','4','Stock Out','16','INV-20260729-F51C64',NULL,'1','2026-07-29 20:50:12');
INSERT INTO `inventory_transactions` (`transaction_id`,`book_id`,`type`,`quantity`,`reference`,`notes`,`performed_by`,`created_at`) VALUES ('14','3','Stock Out','22','INV-20260729-F51C64',NULL,'1','2026-07-29 20:50:12');
INSERT INTO `inventory_transactions` (`transaction_id`,`book_id`,`type`,`quantity`,`reference`,`notes`,`performed_by`,`created_at`) VALUES ('15','8','Stock In','5','PO#3',NULL,'1','2026-07-29 20:53:44');
INSERT INTO `inventory_transactions` (`transaction_id`,`book_id`,`type`,`quantity`,`reference`,`notes`,`performed_by`,`created_at`) VALUES ('16','6','Stock In','5','PO#3',NULL,'1','2026-07-29 20:53:44');
INSERT INTO `inventory_transactions` (`transaction_id`,`book_id`,`type`,`quantity`,`reference`,`notes`,`performed_by`,`created_at`) VALUES ('17','15','Stock In','5','PO#4',NULL,'1','2026-07-29 20:54:01');
INSERT INTO `inventory_transactions` (`transaction_id`,`book_id`,`type`,`quantity`,`reference`,`notes`,`performed_by`,`created_at`) VALUES ('18','15','Stock Out','1','INV-20260730-49E610',NULL,'1','2026-07-30 10:43:50');
INSERT INTO `inventory_transactions` (`transaction_id`,`book_id`,`type`,`quantity`,`reference`,`notes`,`performed_by`,`created_at`) VALUES ('19','16','Stock In','10','Manual','','3','2026-07-30 11:23:34');
INSERT INTO `inventory_transactions` (`transaction_id`,`book_id`,`type`,`quantity`,`reference`,`notes`,`performed_by`,`created_at`) VALUES ('20','16','Stock Out','10','INV-20260730-E19DA0',NULL,'3','2026-07-30 11:24:35');
INSERT INTO `inventory_transactions` (`transaction_id`,`book_id`,`type`,`quantity`,`reference`,`notes`,`performed_by`,`created_at`) VALUES ('21','16','Stock Out','20','INV-20260730-A48A27',NULL,'3','2026-07-30 11:26:07');
INSERT INTO `inventory_transactions` (`transaction_id`,`book_id`,`type`,`quantity`,`reference`,`notes`,`performed_by`,`created_at`) VALUES ('22','16','Stock In','100','Manual','','3','2026-07-30 11:26:25');
INSERT INTO `inventory_transactions` (`transaction_id`,`book_id`,`type`,`quantity`,`reference`,`notes`,`performed_by`,`created_at`) VALUES ('23','16','Stock Out','99','INV-20260730-FF27ED',NULL,'3','2026-07-30 11:27:11');
INSERT INTO `inventory_transactions` (`transaction_id`,`book_id`,`type`,`quantity`,`reference`,`notes`,`performed_by`,`created_at`) VALUES ('24','9','Stock In','2','PO#1',NULL,'3','2026-07-30 11:29:34');
INSERT INTO `inventory_transactions` (`transaction_id`,`book_id`,`type`,`quantity`,`reference`,`notes`,`performed_by`,`created_at`) VALUES ('25','3','Stock In','4','PO#5',NULL,'1','2026-07-30 20:04:05');
INSERT INTO `inventory_transactions` (`transaction_id`,`book_id`,`type`,`quantity`,`reference`,`notes`,`performed_by`,`created_at`) VALUES ('26','16','Stock Out','1','INV-20260803-52967C',NULL,'1','2026-08-03 20:22:27');

DROP TABLE IF EXISTS `login_logs`;
CREATE TABLE `login_logs` (
  `log_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `username_attempt` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('success','failed') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`log_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `login_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('1','1','admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','success','2026-07-28 20:14:39');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('2','1','admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','success','2026-07-28 20:15:27');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('3',NULL,'bookstore_db','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','failed','2026-07-29 18:40:28');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('4','1','admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','success','2026-07-29 18:40:41');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('5','1','admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','failed','2026-07-29 19:09:14');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('6','1','admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','success','2026-07-29 19:09:22');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('7',NULL,'bookstore_db','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','failed','2026-07-29 20:56:08');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('8',NULL,'bookstore_db','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','failed','2026-07-29 20:56:11');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('9','1','admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','failed','2026-07-29 20:56:31');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('10','1','admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','failed','2026-07-29 20:56:32');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('11','1','admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','failed','2026-07-29 20:56:41');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('12','1','admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','failed','2026-07-29 20:56:44');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('13','1','admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','failed','2026-07-29 20:56:44');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('14',NULL,'bookstore_db','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','failed','2026-07-30 10:42:14');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('15','1','admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','success','2026-07-30 10:42:30');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('16',NULL,'bookstore_db','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','failed','2026-07-30 10:46:53');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('17',NULL,'bookstore_db','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','failed','2026-07-30 10:50:38');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('18',NULL,'bookstore_db','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','failed','2026-07-30 10:50:40');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('19',NULL,'bookstore_db','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','failed','2026-07-30 10:50:40');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('20',NULL,'bookstore_db','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','failed','2026-07-30 10:50:40');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('21',NULL,'bookstore_db','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','failed','2026-07-30 10:50:40');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('22',NULL,'bookstore_db','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','failed','2026-07-30 10:50:40');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('23',NULL,'bookstore_db','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','failed','2026-07-30 10:50:41');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('24','1','admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','success','2026-07-30 10:50:56');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('25','1','admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','success','2026-07-30 11:06:25');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('26','3','Manager','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','success','2026-07-30 11:07:54');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('27','1','admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','failed','2026-07-30 11:46:42');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('28','1','admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','success','2026-07-30 11:46:52');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('29',NULL,'manager@gmail.com','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','failed','2026-07-30 11:48:13');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('30','3','manager','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','success','2026-07-30 11:48:19');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('31','1','admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','failed','2026-07-30 11:51:30');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('32','1','admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','success','2026-07-30 11:51:38');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('33','1','admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','success','2026-07-30 19:04:00');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('34','1','admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','failed','2026-07-30 20:03:13');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('35','1','admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','success','2026-07-30 20:03:19');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('36','1','admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','success','2026-07-31 07:17:44');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('37','1','admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','success','2026-07-31 18:35:01');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('38','1','admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','success','2026-08-01 10:44:37');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('39','1','admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','success','2026-08-03 10:43:54');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('40','1','admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','success','2026-08-03 18:28:18');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('41',NULL,'manager@gmail.com','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','failed','2026-08-03 20:21:09');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('42','1','admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','failed','2026-08-03 20:21:24');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('43','1','admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','success','2026-08-03 20:21:32');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('44','1','admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','success','2026-08-05 18:32:44');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('45','1','admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36','success','2026-08-14 17:54:35');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('46','1','admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36','success','2026-08-14 18:08:43');
INSERT INTO `login_logs` (`log_id`,`user_id`,`username_attempt`,`ip_address`,`user_agent`,`status`,`created_at`) VALUES ('47','1','admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36','success','2026-08-15 10:49:56');

DROP TABLE IF EXISTS `membership_levels`;
CREATE TABLE `membership_levels` (
  `membership_id` int NOT NULL AUTO_INCREMENT,
  `level_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `discount_percent` decimal(5,2) DEFAULT '0.00',
  `min_spend` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`membership_id`),
  UNIQUE KEY `level_name` (`level_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `membership_levels` (`membership_id`,`level_name`,`discount_percent`,`min_spend`) VALUES ('1','Bronze','0.00','0.00');
INSERT INTO `membership_levels` (`membership_id`,`level_name`,`discount_percent`,`min_spend`) VALUES ('2','Silver','5.00','100.00');
INSERT INTO `membership_levels` (`membership_id`,`level_name`,`discount_percent`,`min_spend`) VALUES ('3','Gold','10.00','300.00');

DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `notification_id` int NOT NULL AUTO_INCREMENT,
  `type` enum('Low Stock','New Arrival','Purchase Reminder','Promotion','Membership Expiry') COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_read` tinyint(1) DEFAULT '0',
  `user_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`notification_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `publishers`;
CREATE TABLE `publishers` (
  `publisher_id` int NOT NULL AUTO_INCREMENT,
  `publisher_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`publisher_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `publishers` (`publisher_id`,`publisher_name`,`phone`,`email`,`address`,`created_at`) VALUES ('1','បាក់ទូក','098765432','barktuk@gmail.com','#34st,SR','2026-07-28 20:26:45');
INSERT INTO `publishers` (`publisher_id`,`publisher_name`,`phone`,`email`,`address`,`created_at`) VALUES ('2','RongPum','0987983779','rongpum@gmail.com','#30st,SR','2026-07-28 20:27:42');
INSERT INTO `publishers` (`publisher_id`,`publisher_name`,`phone`,`email`,`address`,`created_at`) VALUES ('3','Destiny Rongpum','0878578365','distiny@gmail.com','','2026-07-28 20:30:42');
INSERT INTO `publishers` (`publisher_id`,`publisher_name`,`phone`,`email`,`address`,`created_at`) VALUES ('4','លេខបីបោះពុម្ព','0987654938','lek3bospum@gmail.com','','2026-07-28 20:31:22');
INSERT INTO `publishers` (`publisher_id`,`publisher_name`,`phone`,`email`,`address`,`created_at`) VALUES ('5','ពេញចិត្ត','0788968758','penhjit@gmail.com','','2026-07-28 20:31:56');
INSERT INTO `publishers` (`publisher_id`,`publisher_name`,`phone`,`email`,`address`,`created_at`) VALUES ('6','Golden','0987654323','Gold@gmail.com','','2026-07-28 20:33:13');
INSERT INTO `publishers` (`publisher_id`,`publisher_name`,`phone`,`email`,`address`,`created_at`) VALUES ('7','FaFa168','0123456789','fafa168@gmail.com','New Delhi, India','2026-07-30 11:15:34');

DROP TABLE IF EXISTS `purchase_order_items`;
CREATE TABLE `purchase_order_items` (
  `item_id` int NOT NULL AUTO_INCREMENT,
  `purchase_id` int NOT NULL,
  `book_id` int NOT NULL,
  `quantity` int NOT NULL,
  `unit_cost` decimal(10,2) NOT NULL,
  `subtotal` decimal(12,2) NOT NULL,
  PRIMARY KEY (`item_id`),
  KEY `purchase_id` (`purchase_id`),
  KEY `book_id` (`book_id`),
  CONSTRAINT `purchase_order_items_ibfk_1` FOREIGN KEY (`purchase_id`) REFERENCES `purchase_orders` (`purchase_id`) ON DELETE CASCADE,
  CONSTRAINT `purchase_order_items_ibfk_2` FOREIGN KEY (`book_id`) REFERENCES `books` (`book_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `purchase_order_items` (`item_id`,`purchase_id`,`book_id`,`quantity`,`unit_cost`,`subtotal`) VALUES ('1','1','9','2','10.00','20.00');
INSERT INTO `purchase_order_items` (`item_id`,`purchase_id`,`book_id`,`quantity`,`unit_cost`,`subtotal`) VALUES ('2','2','9','1','10.00','10.00');
INSERT INTO `purchase_order_items` (`item_id`,`purchase_id`,`book_id`,`quantity`,`unit_cost`,`subtotal`) VALUES ('3','2','6','10','7.00','70.00');
INSERT INTO `purchase_order_items` (`item_id`,`purchase_id`,`book_id`,`quantity`,`unit_cost`,`subtotal`) VALUES ('4','2','3','10','8.00','80.00');
INSERT INTO `purchase_order_items` (`item_id`,`purchase_id`,`book_id`,`quantity`,`unit_cost`,`subtotal`) VALUES ('5','3','8','5','10.00','50.00');
INSERT INTO `purchase_order_items` (`item_id`,`purchase_id`,`book_id`,`quantity`,`unit_cost`,`subtotal`) VALUES ('6','3','6','5','7.00','35.00');
INSERT INTO `purchase_order_items` (`item_id`,`purchase_id`,`book_id`,`quantity`,`unit_cost`,`subtotal`) VALUES ('7','4','15','5','5.00','25.00');
INSERT INTO `purchase_order_items` (`item_id`,`purchase_id`,`book_id`,`quantity`,`unit_cost`,`subtotal`) VALUES ('8','5','3','4','8.00','32.00');

DROP TABLE IF EXISTS `purchase_orders`;
CREATE TABLE `purchase_orders` (
  `purchase_id` int NOT NULL AUTO_INCREMENT,
  `po_number` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `supplier_id` int NOT NULL,
  `order_date` date NOT NULL,
  `expected_date` date DEFAULT NULL,
  `status` enum('Pending','Received','Cancelled') COLLATE utf8mb4_unicode_ci DEFAULT 'Pending',
  `total_amount` decimal(12,2) DEFAULT '0.00',
  `created_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`purchase_id`),
  UNIQUE KEY `po_number` (`po_number`),
  KEY `supplier_id` (`supplier_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `purchase_orders_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`supplier_id`),
  CONSTRAINT `purchase_orders_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `purchase_orders` (`purchase_id`,`po_number`,`supplier_id`,`order_date`,`expected_date`,`status`,`total_amount`,`created_by`,`created_at`) VALUES ('1','PO-20260728-7454E9','2','2026-07-28','2026-07-29','Received','20.00','1','2026-07-28 21:08:30');
INSERT INTO `purchase_orders` (`purchase_id`,`po_number`,`supplier_id`,`order_date`,`expected_date`,`status`,`total_amount`,`created_by`,`created_at`) VALUES ('2','PO-20260728-5983B3','1','2026-07-28','2026-07-10','Received','160.00','1','2026-07-28 21:09:20');
INSERT INTO `purchase_orders` (`purchase_id`,`po_number`,`supplier_id`,`order_date`,`expected_date`,`status`,`total_amount`,`created_by`,`created_at`) VALUES ('3','PO-20260728-F677B2','3','2026-07-28','2026-07-03','Received','85.00','1','2026-07-28 21:14:27');
INSERT INTO `purchase_orders` (`purchase_id`,`po_number`,`supplier_id`,`order_date`,`expected_date`,`status`,`total_amount`,`created_by`,`created_at`) VALUES ('4','PO-20260729-F9D02A','2','2026-07-29',NULL,'Received','25.00','1','2026-07-29 20:53:58');
INSERT INTO `purchase_orders` (`purchase_id`,`po_number`,`supplier_id`,`order_date`,`expected_date`,`status`,`total_amount`,`created_by`,`created_at`) VALUES ('5','PO-20260730-31FC28','2','2026-07-30','2026-07-03','Received','32.00','1','2026-07-30 20:00:41');

DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `role_id` int NOT NULL AUTO_INCREMENT,
  `role_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`role_id`),
  UNIQUE KEY `role_name` (`role_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `roles` (`role_id`,`role_name`) VALUES ('1','Admin');
INSERT INTO `roles` (`role_id`,`role_name`) VALUES ('3','Cashier');
INSERT INTO `roles` (`role_id`,`role_name`) VALUES ('2','Manager');

DROP TABLE IF EXISTS `sale_items`;
CREATE TABLE `sale_items` (
  `sale_item_id` int NOT NULL AUTO_INCREMENT,
  `sale_id` int NOT NULL,
  `book_id` int NOT NULL,
  `quantity` int NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `subtotal` decimal(12,2) NOT NULL,
  PRIMARY KEY (`sale_item_id`),
  KEY `sale_id` (`sale_id`),
  KEY `book_id` (`book_id`),
  CONSTRAINT `sale_items_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`sale_id`) ON DELETE CASCADE,
  CONSTRAINT `sale_items_ibfk_2` FOREIGN KEY (`book_id`) REFERENCES `books` (`book_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `sale_items` (`sale_item_id`,`sale_id`,`book_id`,`quantity`,`unit_price`,`subtotal`) VALUES ('1','1','2','3','10.00','30.00');
INSERT INTO `sale_items` (`sale_item_id`,`sale_id`,`book_id`,`quantity`,`unit_price`,`subtotal`) VALUES ('2','2','9','9','15.00','135.00');
INSERT INTO `sale_items` (`sale_item_id`,`sale_id`,`book_id`,`quantity`,`unit_price`,`subtotal`) VALUES ('3','2','8','7','16.00','112.00');
INSERT INTO `sale_items` (`sale_item_id`,`sale_id`,`book_id`,`quantity`,`unit_price`,`subtotal`) VALUES ('4','2','15','8','8.00','64.00');
INSERT INTO `sale_items` (`sale_item_id`,`sale_id`,`book_id`,`quantity`,`unit_price`,`subtotal`) VALUES ('5','2','6','24','10.00','240.00');
INSERT INTO `sale_items` (`sale_item_id`,`sale_id`,`book_id`,`quantity`,`unit_price`,`subtotal`) VALUES ('6','2','5','4','13.00','52.00');
INSERT INTO `sale_items` (`sale_item_id`,`sale_id`,`book_id`,`quantity`,`unit_price`,`subtotal`) VALUES ('7','2','4','16','14.00','224.00');
INSERT INTO `sale_items` (`sale_item_id`,`sale_id`,`book_id`,`quantity`,`unit_price`,`subtotal`) VALUES ('8','2','3','22','13.00','286.00');
INSERT INTO `sale_items` (`sale_item_id`,`sale_id`,`book_id`,`quantity`,`unit_price`,`subtotal`) VALUES ('9','3','15','1','8.00','8.00');
INSERT INTO `sale_items` (`sale_item_id`,`sale_id`,`book_id`,`quantity`,`unit_price`,`subtotal`) VALUES ('10','4','16','10','99.99','999.90');
INSERT INTO `sale_items` (`sale_item_id`,`sale_id`,`book_id`,`quantity`,`unit_price`,`subtotal`) VALUES ('11','5','16','20','99.99','1999.80');
INSERT INTO `sale_items` (`sale_item_id`,`sale_id`,`book_id`,`quantity`,`unit_price`,`subtotal`) VALUES ('12','6','16','99','99.99','9899.01');
INSERT INTO `sale_items` (`sale_item_id`,`sale_id`,`book_id`,`quantity`,`unit_price`,`subtotal`) VALUES ('13','7','16','1','99.99','99.99');

DROP TABLE IF EXISTS `sale_returns`;
CREATE TABLE `sale_returns` (
  `return_id` int NOT NULL AUTO_INCREMENT,
  `sale_id` int NOT NULL,
  `book_id` int NOT NULL,
  `quantity` int NOT NULL,
  `reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `refund_amount` decimal(10,2) NOT NULL,
  `processed_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`return_id`),
  KEY `sale_id` (`sale_id`),
  KEY `book_id` (`book_id`),
  KEY `processed_by` (`processed_by`),
  CONSTRAINT `sale_returns_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`sale_id`),
  CONSTRAINT `sale_returns_ibfk_2` FOREIGN KEY (`book_id`) REFERENCES `books` (`book_id`),
  CONSTRAINT `sale_returns_ibfk_3` FOREIGN KEY (`processed_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `sales`;
CREATE TABLE `sales` (
  `sale_id` int NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_id` int DEFAULT NULL,
  `cashier_id` int NOT NULL,
  `discount_id` int DEFAULT NULL,
  `subtotal` decimal(12,2) NOT NULL DEFAULT '0.00',
  `discount_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `tax_percent` decimal(5,2) NOT NULL DEFAULT '0.00',
  `tax_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `total_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `payment_method` enum('Cash','Card','Mobile') COLLATE utf8mb4_unicode_ci DEFAULT 'Cash',
  `amount_paid` decimal(12,2) DEFAULT '0.00',
  `change_due` decimal(12,2) DEFAULT '0.00',
  `status` enum('Completed','Cancelled','Refunded') COLLATE utf8mb4_unicode_ci DEFAULT 'Completed',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`sale_id`),
  UNIQUE KEY `invoice_number` (`invoice_number`),
  KEY `customer_id` (`customer_id`),
  KEY `cashier_id` (`cashier_id`),
  KEY `discount_id` (`discount_id`),
  KEY `idx_created` (`created_at`),
  CONSTRAINT `sales_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`) ON DELETE SET NULL,
  CONSTRAINT `sales_ibfk_2` FOREIGN KEY (`cashier_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `sales_ibfk_3` FOREIGN KEY (`discount_id`) REFERENCES `discounts` (`discount_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `sales` (`sale_id`,`invoice_number`,`customer_id`,`cashier_id`,`discount_id`,`subtotal`,`discount_amount`,`tax_percent`,`tax_amount`,`total_amount`,`payment_method`,`amount_paid`,`change_due`,`status`,`created_at`) VALUES ('1','INV-20260728-36D1EB',NULL,'1',NULL,'30.00','0.00','0.00','0.00','30.00','Cash','32.00','2.00','Completed','2026-07-28 21:12:32');
INSERT INTO `sales` (`sale_id`,`invoice_number`,`customer_id`,`cashier_id`,`discount_id`,`subtotal`,`discount_amount`,`tax_percent`,`tax_amount`,`total_amount`,`payment_method`,`amount_paid`,`change_due`,`status`,`created_at`) VALUES ('2','INV-20260729-F51C64',NULL,'1',NULL,'1113.00','0.00','0.00','0.00','1113.00','Cash','0.00','0.00','Completed','2026-07-29 20:50:12');
INSERT INTO `sales` (`sale_id`,`invoice_number`,`customer_id`,`cashier_id`,`discount_id`,`subtotal`,`discount_amount`,`tax_percent`,`tax_amount`,`total_amount`,`payment_method`,`amount_paid`,`change_due`,`status`,`created_at`) VALUES ('3','INV-20260730-49E610',NULL,'1',NULL,'8.00','0.00','0.00','0.00','8.00','Cash','0.00','0.00','Completed','2026-07-30 10:43:50');
INSERT INTO `sales` (`sale_id`,`invoice_number`,`customer_id`,`cashier_id`,`discount_id`,`subtotal`,`discount_amount`,`tax_percent`,`tax_amount`,`total_amount`,`payment_method`,`amount_paid`,`change_due`,`status`,`created_at`) VALUES ('4','INV-20260730-E19DA0',NULL,'3',NULL,'999.90','0.00','0.00','0.00','999.90','Mobile','999.90','0.00','Completed','2026-07-30 11:24:35');
INSERT INTO `sales` (`sale_id`,`invoice_number`,`customer_id`,`cashier_id`,`discount_id`,`subtotal`,`discount_amount`,`tax_percent`,`tax_amount`,`total_amount`,`payment_method`,`amount_paid`,`change_due`,`status`,`created_at`) VALUES ('5','INV-20260730-A48A27',NULL,'3',NULL,'1999.80','0.00','0.00','0.00','1999.80','Cash','1999.80','0.00','Completed','2026-07-30 11:26:07');
INSERT INTO `sales` (`sale_id`,`invoice_number`,`customer_id`,`cashier_id`,`discount_id`,`subtotal`,`discount_amount`,`tax_percent`,`tax_amount`,`total_amount`,`payment_method`,`amount_paid`,`change_due`,`status`,`created_at`) VALUES ('6','INV-20260730-FF27ED',NULL,'3',NULL,'9899.01','0.00','0.00','0.00','9899.01','Cash','9899.01','0.00','Completed','2026-07-30 11:27:11');
INSERT INTO `sales` (`sale_id`,`invoice_number`,`customer_id`,`cashier_id`,`discount_id`,`subtotal`,`discount_amount`,`tax_percent`,`tax_amount`,`total_amount`,`payment_method`,`amount_paid`,`change_due`,`status`,`created_at`) VALUES ('7','INV-20260803-52967C',NULL,'1',NULL,'99.99','0.00','0.00','0.00','99.99','Cash','0.00','0.00','Completed','2026-08-03 20:22:27');

DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `setting_key` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `setting_value` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES ('currency_code','USD');
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES ('currency_symbol','$');
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES ('low_stock_threshold','5');
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES ('receipt_footer_message','Thank you for your purchase!');
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES ('store_address','#30st,SR');
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES ('store_email','Bookstore@gmail.com');
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES ('store_logo','logo_6b257a68ac62d394f40aa2ac.jpg');
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES ('store_name','Bookstore');
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES ('store_phone','098765433');
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES ('tax_percent','0');

DROP TABLE IF EXISTS `suppliers`;
CREATE TABLE `suppliers` (
  `supplier_id` int NOT NULL AUTO_INCREMENT,
  `supplier_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_person` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`supplier_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `suppliers` (`supplier_id`,`supplier_name`,`contact_person`,`phone`,`email`,`address`,`status`,`created_at`) VALUES ('1','monika','momo','09876547356','monika@gmail.com','#30st,sr','active','2026-07-28 20:33:57');
INSERT INTO `suppliers` (`supplier_id`,`supplier_name`,`contact_person`,`phone`,`email`,`address`,`status`,`created_at`) VALUES ('2','Elonmask','Kimvuo Hut','090876543','kimvuohut@gmail.com','','active','2026-07-28 20:35:48');
INSERT INTO `suppliers` (`supplier_id`,`supplier_name`,`contact_person`,`phone`,`email`,`address`,`status`,`created_at`) VALUES ('3','Iron','danma','0876567896','dfhhyb@gmail.com','','active','2026-07-28 20:36:23');
INSERT INTO `suppliers` (`supplier_id`,`supplier_name`,`contact_person`,`phone`,`email`,`address`,`status`,`created_at`) VALUES ('4','Mark','Sokserey','098765460','Serey@gmail.com','','active','2026-07-28 20:44:07');
INSERT INTO `suppliers` (`supplier_id`,`supplier_name`,`contact_person`,`phone`,`email`,`address`,`status`,`created_at`) VALUES ('5','Rich-dude','dude','0987654321','veryrich@gmail.com','Dubai, UAE','active','2026-07-30 11:17:57');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `full_name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role_id` int NOT NULL,
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `profile_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `failed_login_attempts` int DEFAULT '0',
  `locked_until` datetime DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `role_id` (`role_id`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` (`user_id`,`username`,`email`,`password_hash`,`full_name`,`phone`,`role_id`,`status`,`profile_image`,`failed_login_attempts`,`locked_until`,`last_login`,`created_at`,`updated_at`) VALUES ('1','admin','admin@gmail.com','$2y$10$ztz8L/a7a/D2H5SJ.cr5BeVwu0FYkw3hZQyiUsDcK2YDeAn2AsmXu','System Administrator','0987654345','1','active','avatar_1_b371e6ddaee813c49f425687.jpg','0',NULL,'2026-08-15 10:49:56','2026-07-28 20:13:40','2026-08-15 10:49:56');
INSERT INTO `users` (`user_id`,`username`,`email`,`password_hash`,`full_name`,`phone`,`role_id`,`status`,`profile_image`,`failed_login_attempts`,`locked_until`,`last_login`,`created_at`,`updated_at`) VALUES ('3','Manager','manager@gmail.com','$2y$10$qA5s1f4G6X6Bq958nQr8..WK9/AMXiYNNpnummKVhGxdU3/3DSxYe','manager','098765465','2','active',NULL,'0',NULL,'2026-07-30 11:48:19','2026-07-30 11:07:36','2026-07-30 11:48:19');

DROP TABLE IF EXISTS `view_best_sellers`;
;

INSERT INTO `view_best_sellers` (`book_id`,`title`,`total_sold`) VALUES ('16','The Art of Scamming','130');
INSERT INTO `view_best_sellers` (`book_id`,`title`,`total_sold`) VALUES ('6','Critical Thinking','24');
INSERT INTO `view_best_sellers` (`book_id`,`title`,`total_sold`) VALUES ('3','Information Security and Cyber Laws','22');
INSERT INTO `view_best_sellers` (`book_id`,`title`,`total_sold`) VALUES ('4','Leadership','16');
INSERT INTO `view_best_sellers` (`book_id`,`title`,`total_sold`) VALUES ('9','Javascript','9');
INSERT INTO `view_best_sellers` (`book_id`,`title`,`total_sold`) VALUES ('15','chemistry','9');
INSERT INTO `view_best_sellers` (`book_id`,`title`,`total_sold`) VALUES ('8','Cybersecurity','7');
INSERT INTO `view_best_sellers` (`book_id`,`title`,`total_sold`) VALUES ('5','Public Finace','4');
INSERT INTO `view_best_sellers` (`book_id`,`title`,`total_sold`) VALUES ('2','Accounting information system','3');

DROP TABLE IF EXISTS `view_low_stock`;
;

INSERT INTO `view_low_stock` (`book_id`,`title`,`isbn`,`quantity`,`reorder_level`) VALUES ('2','Accounting information system','02','1','2');
INSERT INTO `view_low_stock` (`book_id`,`title`,`isbn`,`quantity`,`reorder_level`) VALUES ('4','Leadership','04','0','2');
INSERT INTO `view_low_stock` (`book_id`,`title`,`isbn`,`quantity`,`reorder_level`) VALUES ('5','Public Finace','05','1','3');
INSERT INTO `view_low_stock` (`book_id`,`title`,`isbn`,`quantity`,`reorder_level`) VALUES ('8','Cybersecurity','08','5','5');
INSERT INTO `view_low_stock` (`book_id`,`title`,`isbn`,`quantity`,`reorder_level`) VALUES ('9','Javascript','09','2','5');

DROP TABLE IF EXISTS `work_schedule`;
CREATE TABLE `work_schedule` (
  `schedule_id` int NOT NULL AUTO_INCREMENT,
  `employee_id` int NOT NULL,
  `shift_day` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shift_start` time NOT NULL,
  `shift_end` time NOT NULL,
  PRIMARY KEY (`schedule_id`),
  KEY `employee_id` (`employee_id`),
  CONSTRAINT `work_schedule_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`employee_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


SET FOREIGN_KEY_CHECKS=1;
