<?php
/**
 * Copy this file to "database.local.php" in the same folder and set your real values.
 * database.local.php is listed in .gitignore and will NEVER be pushed to GitHub.
 */

define('DB_HOST', 'localhost');
define('DB_NAME', 'bookstore_db');
define('DB_USER', 'root');
define('DB_PASS', '');
