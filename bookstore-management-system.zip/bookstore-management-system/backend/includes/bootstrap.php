<?php
/**
 * Every API endpoint starts with: require_once __DIR__ . '/../../includes/bootstrap.php';
 */
require_once __DIR__ . '/../config/config.php';
sendSecurityHeaders();
